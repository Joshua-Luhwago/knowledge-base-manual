# Multimodal Knowledge Base / 多模态知识库

| Edition / 版本 | Markdown | PDF | HTML |
|---|---|---|---|
| English | [Operating manual](INTERFACE_GUIDE.md) | [English PDF](https://joshua-luhwago.github.io/knowledge-base-manual/INTERFACE_GUIDE.pdf) | [English HTML](INTERFACE_GUIDE.html) |
| 中文 | [功能演示与操作手册](INTERFACE_GUIDE_ZH.md) | [中文 PDF](https://joshua-luhwago.github.io/knowledge-base-manual/INTERFACE_GUIDE_ZH.pdf) | [中文 HTML](INTERFACE_GUIDE_ZH.html) |

Actual screenshots, six normal-speed, silent browser recordings, an animated preview, video frame grabs, synthetic sample workbooks, the submitted diagnosis request, and saved evidence accompany both editions. The HTML versions include video players. PDFs use stills and links.

Coverage includes all reachable pages, document/multimodal processing, dataset operations, vector and graph APIs, Q&A, diagnosis/reports, monitoring, authentication, maintenance and CLI tools. The endpoint catalogue includes every registered Flask route declaration; internal declarations have a separate source inventory.

The demonstration uses an isolated Neo4j graph and an isolated InfluxDB bucket. The refreshed tour shows graph search, a fresh Voyage 4 Nano-backed answer, and populated monitoring charts.

The download ZIP includes the HTML and Markdown manuals, sample workbooks, and saved evidence. The English and Chinese PDFs are available alongside the ZIP on the published Pages site. Its HTML and Markdown editions load screenshots and recordings from the published Pages site; the full capture assets and tools remain in this repository.

See [rebuild/capture instructions](tools/README.md) and [validation record](evidence/VALIDATION.md).
