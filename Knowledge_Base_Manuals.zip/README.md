# Multimodal Knowledge Base / 多模态知识库

| Edition / 版本 | Markdown | PDF | HTML |
|---|---|---|---|
| English | [Operating manual](INTERFACE_GUIDE.md) | [English PDF](INTERFACE_GUIDE.pdf) | [English HTML](INTERFACE_GUIDE.html) |
| 中文 | [功能演示与操作手册](INTERFACE_GUIDE_ZH.md) | [中文 PDF](INTERFACE_GUIDE_ZH.pdf) | [中文 HTML](INTERFACE_GUIDE_ZH.html) |

Actual screenshots, five normal-speed, silent browser recordings with continuous cursor movement and click pulses, an animated preview, video frame grabs, a synthetic sample workbook, the submitted diagnosis request, and saved evidence accompany both editions. The HTML versions include video players. PDFs use stills and links.

Coverage includes all reachable pages, document/multimodal processing, dataset operations, vector and graph APIs, Q&A, diagnosis/reports, monitoring, authentication, maintenance and CLI tools. The endpoint catalogue includes every registered Flask route declaration; internal declarations have a separate source inventory.

At capture time, Neo4j and InfluxDB were unavailable, and fresh Q&A failed on the configured embedding path. Neo4j connectivity was subsequently restored with the existing local container and working credentials. The guides now explain the local Voyage 4 Nano query option and the InfluxDB setup required for monitoring. Screenshots and recordings retain their original states.

See [rebuild/capture instructions](tools/README.md) and [validation record](evidence/VALIDATION.md).
