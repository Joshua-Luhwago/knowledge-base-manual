"""Build parallel English/Chinese operating guides from reviewed bilingual content."""
from pathlib import Path
import ast,csv,json,re
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'docs/manual'
sections=[]
def add(en,zh):sections.append((en.strip(),zh.strip()))
def figures(*items):
 return '\n\n'.join(f'![{caption}](screenshots/{name}.png)' for name,caption in items)
add('''# Multimodal Knowledge Base — operating manual and visual demonstration

**English edition · 2 November 2026 · Local repository snapshot**

This guide follows the reference interface manual, with additional completed workflows, recorded browser demonstrations, API coverage and reproducible inputs. On-screen labels remain Chinese so that English readers can find the controls.

**Evidence scope:** Screenshots and recordings are actual captures of this repository served at `http://127.0.0.1:5175`, with Flask on `5002`. The separate Agent-System copy on `5174/5001` was not used for these demonstrations. Automatic startup rebuilding was disabled (`DISABLE_KB_BOOTSTRAP=1`) to preserve the existing index. Initial inventory: 123 visible files; the saved index summary records 138 documents and 5,719 chunks. These are different inventories, not equivalent counts. Demonstration uploads can change the visible count.

Confidence is **high** for captured actions and source-verified controls. External-service success is **unverified** where the service was unavailable. All demonstration measurements are synthetic.

## Contents

1. Quick start and workflow map
2. Home, navigation and appearance
3. Import and upload history
4. PDF parsing and multimodal processing
5. Completed spreadsheet import and editing
6. Dataset management, previews and recovery
7. Vector retrieval and index maintenance
8. Knowledge graph
9. Evidence-based questions
10. Diagnosis: three input modes
11. Saved reports and source evidence
12. Condition monitoring
13. Accounts and management
14. Recordings and screen grabs
15. API examples and endpoint catalogue
16. Command-line tools and troubleshooting''','''# 多模态知识库——功能演示与操作手册

**中文版 · 2026 年 11 月 2 日 · 本地仓库版本快照**

本手册沿用参考文档的图文操作形式，补充已实际完成的流程、浏览器录屏、接口目录及可复现输入。按钮名称与中文界面保持一致。

**证据范围：** 截图与录屏均来自本仓库，前端演示地址为 `http://127.0.0.1:5175`，Flask 使用 `5002` 端口。未将另一份 Agent-System 中 `5174/5001` 的副本用作本次演示。启动时设置 `DISABLE_KB_BOOTSTRAP=1`，避免自动重建已有索引。初始清点为 123 份可见文件；已有索引摘要记录 138 份文档、5,719 个文本块。两者统计口径不同，不能视为同一数量。演示上传会改变可见文件数量。

已截图操作和源码核实功能的置信度为**高**；服务不可用时，其成功执行状态为**未验证**。所有演示测量值均为合成数据。

## 目录

1. 启动与工作流程
2. 首页、导航与主题
3. 导入入口与上传历史
4. PDF 解析与多模态处理
5. 已完成的 Excel 导入与编辑
6. 数据集管理、预览与恢复
7. 向量检索与索引维护
8. 知识图谱
9. 带证据的知识问答
10. 三种输入模式的诊断
11. 持久化报告与来源证据
12. 设备状态监测
13. 账号与平台管理
14. 录屏与视频截帧
15. 接口示例与完整目录
16. 命令行工具与故障处理''')
add('''## 1. Quick start and workflow map

Use an existing project environment (`venv/` or `.venv/`). Never install project dependencies in conda base. In separate terminals:

```bash
source venv/bin/activate
python app.py
```

```bash
cd frontend
npm run dev
```

Default development frontend: `http://127.0.0.1:5173`. Backend port comes from `.env`; the supplied example uses `5001`. Vite proxies `/api` and `/pdfs` to that backend. The `5175/5002` ports in this guide were isolated capture ports. A built `frontend/dist` can also be served by Flask.

**Main workflow:** import one file → extraction/cleaning → compare source and Markdown → edit if needed → **保存并入库** → find the document in **数据集管理** → use retrieval/graph/Q&A → enter an anomaly in **诊断报告** → open its saved report.

| Destination | Route | Main action |
|---|---|---|
| 首页 | `/` | Asset overview, shortcuts and recent questions |
| 知识导入 | `/parse` | Upload history and new import |
| Import workspace | `/parse/create` | Upload, inspect, edit, save |
| 数据集管理 | `/dataset` | Filter, preview, rename and delete |
| 知识图谱 | `/graph` | Search, inspect relations and evidence chains |
| 知识问答 | `/qa` | Ask questions and inspect citations |
| 诊断报告 | `/diagnosis` | Run anomaly diagnosis |
| Saved report | `/reports/<reportId>` | Reopen a persistent report |
| 状态监测 | `/timeseries` | Import and visualize equipment series |
| 平台管理 | `/manage` | Current management entry screen |

`/vector`, `/vector/documents` and `/vector/documents/:docKey` redirect to `/dataset`. `VectorPage.vue` exists in the source tree but is not registered as a reachable page.''','''## 1. 启动与工作流程

使用项目已有的 `venv/` 或 `.venv/` 环境，不得向 conda base 安装项目依赖。在两个终端分别运行：

```bash
source venv/bin/activate
python app.py
```

```bash
cd frontend
npm run dev
```

默认开发前端为 `http://127.0.0.1:5173`。后端端口读取 `.env`，示例配置为 `5001`。Vite 将 `/api`、`/pdfs` 转发至后端。本手册使用 `5175/5002` 作为隔离的截图端口。构建后的 `frontend/dist` 也可由 Flask 提供页面服务。

**主流程：** 上传单份资料 → 抽取与清洗 → 对照源文件和 Markdown → 必要时编辑 → **保存并入库** → 在**数据集管理**定位 → 检索、图谱或问答 → 在**诊断报告**输入异常 → 打开持久化报告。

| 功能入口 | 路由 | 主要操作 |
|---|---|---|
| 首页 | `/` | 资产总览、业务入口与近期问题 |
| 知识导入 | `/parse` | 上传历史与新建导入 |
| 导入工作区 | `/parse/create` | 上传、检查、编辑与保存 |
| 数据集管理 | `/dataset` | 筛选、预览、重命名与删除 |
| 知识图谱 | `/graph` | 检索实体、关系和证据链 |
| 知识问答 | `/qa` | 提问并查看引用 |
| 诊断报告 | `/diagnosis` | 执行异常诊断 |
| 已保存报告 | `/reports/<reportId>` | 重新打开持久化报告 |
| 状态监测 | `/timeseries` | 时序导入与设备曲线 |
| 平台管理 | `/manage` | 当前的管理入口页面 |

`/vector`、`/vector/documents`、`/vector/documents/:docKey` 均重定向到 `/dataset`。源码中的 `VectorPage.vue` 未注册为可访问页面。''')
add('''## 2. Home, navigation and appearance

Open **首页**. The page presents the knowledge workflow, asset composition, processing-state counts, category distribution, condition-monitoring area and suggested/recent questions. Scroll down for module cards; **进入系统** and module links lead into workspaces. Summary, quality and distribution are supplied by distinct APIs, so their counts can differ.

Use the top navigation to change work areas. The theme switch toggles light/dark appearance and stores the choice in browser local storage. **设置 → 用户管理** opens `/manage`; **退出** currently returns to the home page.

'''+figures(('33-home-loaded','Home after data loading'),('02-theme','Light appearance'),('03-settings','Settings menu')),
'''## 2. 首页、导航与主题

打开**首页**，查看知识建设流程、资产类型构成、处理状态统计、分类分布、状态监测区域及推荐或近期问题。向下滚动可见业务模块卡片，通过**进入系统**或模块链接打开工作区。总览、质量与分布来自不同接口，统计值可能不同。

顶部导航用于切换模块。主题开关在明暗模式间切换，选择保存在浏览器本地存储。**设置 → 用户管理**进入 `/manage`；当前**退出**操作返回首页。

'''+figures(('33-home-loaded','数据加载后的首页'),('02-theme','浅色主题'),('03-settings','设置菜单')))
add('''## 3. Import and upload history

Open **知识导入**. **开始导入** opens the upload workspace. The history table shows file name/type, destination category, upload time, state and available location actions. Use its search field, type filter (PDF/image/Excel/audio/video) and state filter (completed/processing/failed) to narrow the list. **查看定位** opens the corresponding dataset file when one has been committed.

In `/parse/create`, click or drag a single supported file into the upload zone. Fill **文档名称**, select **保存栏目**, or select **+ 新增栏目** and enter a name. Remove an incorrectly queued file before submitting. PDF inputs additionally expose **解析策略**. Start processing using the upload action, then follow the timeline and log entries.

The file picker accepts PDF, Excel (`xlsx/xls/xlsm`), common images, audio and video extensions. Each displayed upload is one file. Internal queue code does not imply a multi-file batch picker.

'''+figures(('04-import','Import history and workflow'),('05-upload','New import workspace'),('23-upload-selected','Selected file and destination controls')),
'''## 3. 导入入口与上传历史

打开**知识导入**，点击**开始导入**进入上传工作区。历史表显示名称、类型、保存栏目、上传时间、状态及可用定位操作。可使用名称搜索、文件类型筛选（PDF、图片、Excel、音频、视频）及状态筛选（已完成、处理中、失败）。文件已保存入库时，**查看定位**打开相应数据集条目。

在 `/parse/create` 点击上传区域或拖入单份支持的文件，填写**文档名称**，选择**保存栏目**；选择**+ 新增栏目**时填写栏目名。排队文件选错时先移除。PDF 还可选择**解析策略**。提交后观察处理时间线与日志。

文件选择器接受 PDF、Excel（`xlsx/xls/xlsm`）、常见图片、音频与视频扩展名。界面每次上传一份资料；内部队列逻辑不代表已有多文件批量选择器。

'''+figures(('04-import','导入流程与上传历史'),('05-upload','新建导入工作区'),('23-upload-selected','已选择文件与保存栏目')))
add('''## 4. PDF parsing and multimodal processing

| Input | Processing and operator action | Verification in this session |
|---|---|---|
| PDF | **自动（推荐）**, **高保真文本（PyPDF）**, **复杂版面（Docling）**, or **扫描件全页 OCR**. Compare source and extracted text; change strategy and use **重新解析** for an eligible uncommitted task. | Existing source PDF, extracted text and chunks opened; new OCR/Docling runs not performed. |
| Excel | Parse workbook sheets into Markdown tables; inspect the sheet preview and extracted text. | New two-row workbook processed, edited and committed. |
| Image | Local Ollama or configured remote vision processing produces Markdown; compare with source image. | Existing source image preview opened; new model inference not run. |
| Audio | Speech recognition produces a transcript, then an LLM organizes cleaned Markdown. | Source-verified implementation; no audio sample present for execution. |
| Video, remote | Default remote path extracts audio and returns its ASR transcript. | Source-verified implementation; not executed. |
| Video, local | `MM_VIDEO_PROVIDER=local` or `ollama`: FFmpeg samples frames; local vision model describes frames and produces Markdown. | Source-verified implementation; not executed. |

Remote video processing is **transcript-only** in the current implementation; it does not also perform visual defect detection. Local video processing uses frame summaries. FFmpeg/ffprobe and the selected model service are required for these paths.

The preview supports source PDFs, images, workbook sheets and native audio/video players when a source exists. **编辑 → 保存** updates the extraction draft; **保存并入库** is a separate step that commits the source and cleaned/edited Markdown. Saving triggers incremental knowledge ingestion, whose vector/graph success depends on its services.

'''+figures(('07-source','Existing PDF source preview'),('08-extraction','Existing extracted Markdown'),('09-chunks','Empty chunk state for one existing document'),('51-populated-chunks','Populated chunk list from another existing document')),
'''## 4. PDF 解析与多模态处理

| 输入 | 处理方式与操作 | 本次验证情况 |
|---|---|---|
| PDF | 选择**自动（推荐）**、**高保真文本（PyPDF）**、**复杂版面（Docling）**或**扫描件全页 OCR**。对照源文件和抽取结果；未入库任务满足条件时可改策略并**重新解析**。 | 打开了已有 PDF 原文、抽取文本和切分块；未新跑 OCR/Docling。 |
| Excel | 将工作表转为 Markdown 表格，可查看源表和抽取结果。 | 新建两行工作簿，完成抽取、编辑与保存入库。 |
| 图片 | 使用本地 Ollama 或配置的远程视觉模型生成 Markdown，与原图对照。 | 打开了已有原图；未执行新一轮模型推理。 |
| 音频 | 语音识别生成转写文本，再由语言模型整理成清洗稿。 | 已核实源码；未提供可运行的音频样本。 |
| 视频：远程 | 默认远程路径提取音轨，返回语音转写。 | 已核实源码，未执行。 |
| 视频：本地 | `MM_VIDEO_PROVIDER=local` 或 `ollama`：FFmpeg 抽帧，交给本地视觉模型逐帧生成 Markdown。 | 已核实源码，未执行。 |

当前远程视频路径**仅进行音轨转写**，不同时执行视觉缺陷检测；本地路径生成关键帧描述。相关流程需要 FFmpeg/ffprobe 和对应模型服务。

源文件存在时，预览区支持 PDF、图片、工作表及原生音视频播放器。**编辑 → 保存**更新抽取草稿；另行点击**保存并入库**，才会保存源文件和清洗稿或编辑稿。入库会触发增量知识处理，其向量及图谱阶段是否成功取决于相关服务。

'''+figures(('07-source','已有 PDF 源文件'),('08-extraction','已有 Markdown 抽取结果'),('09-chunks','一份已有文档的空切分状态'),('51-populated-chunks','另一份已有文档的实际切分块')))
add('''## 5. Completed spreadsheet import and editing

Reproduce with [manual-demo.xlsx](samples/manual-demo.xlsx). The sheet **主变压器时序** contains two synthetic readings for `MANUAL-DEMO-001`: 72/76°C and 42/46 MW, at 08:00/09:00 on 1 November 2026 (+08:00).

1. Upload the workbook and name it `Manual demo — synthetic transformer readings`.
2. Wait for **表格解析** and **文本清洗** to complete. The observed engine was `openpyxl+pandas`.
3. Review the source table beside the Markdown table. Processing may open an enlarged preview automatically; use **关闭** to return to the workspace.
4. Click **编辑**, amend the Markdown, then **保存**. The demonstrated edit explicitly labels the readings synthetic.
5. Click **保存并入库**. Find the saved workbook in the dataset, reopen it, and verify **抽取结果** contains the edited draft.

**Observed result:** the source workbook remained readable; the edited Markdown was retained after commit. Incremental retrieval ingestion did not establish a successful new searchable index in this environment. Workbook import into the knowledge library is separate from **状态监测** import into InfluxDB.

'''+figures(('24-upload-processed','Actual workbook extraction'),('25-markdown-edit','Editing the extraction draft'),('26-markdown-saved','Saved draft before commit'),('44-edited-extraction','Edited content reopened from the library')),
'''## 5. 已完成的 Excel 导入与编辑

可使用 [manual-demo.xlsx](samples/manual-demo.xlsx) 复现。**主变压器时序**工作表包含设备 `MANUAL-DEMO-001` 的两行合成数据：2026 年 11 月 1 日 08:00、09:00（+08:00）的温度 72/76°C、负荷 42/46 MW。

1. 上传工作簿，命名为 `Manual demo — synthetic transformer readings`。
2. 等待**表格解析**和**文本清洗**完成；本次实际使用 `openpyxl+pandas` 引擎。
3. 对照源表与 Markdown。处理完成后可能自动打开放大预览，点击**关闭**返回工作区。
4. 点击**编辑**，修改 Markdown，再点击**保存**。演示修改中明确注明数据为合成数据。
5. 点击**保存并入库**，在数据集中重新打开工作簿，并确认**抽取结果**保留编辑稿。

**实际结果：** 源表可正常查看，提交后保留了编辑后的 Markdown。本环境未验证增量检索入库成功形成新的可搜索索引。知识库中的 Excel 导入与**状态监测**写入 InfluxDB 是两条不同流程。

'''+figures(('24-upload-processed','实际的工作表抽取'),('25-markdown-edit','编辑抽取草稿'),('26-markdown-saved','提交入库前保存草稿'),('44-edited-extraction','从数据集重新打开的编辑稿')))
add('''## 6. Dataset management, previews and recovery

Open **数据集管理**. Filter using **资料分类 → 设备对象 → 业务场景**, with **使用场景** as an additional facet. Search by document name/device type. Switch between **文档** and **图片**, collapse the sidebar, use **上一页/下一页**, or select rows with checkboxes. Selection alone does not expose a batch operation in this template.

Click a document name to open its preview. Use source preview, **抽取结果**, **切分块**, open-source-file, fullscreen and close controls. PDFs use an iframe; images show the original; workbooks show sheet tabs and cell tables. Some existing entries display **未知** because their title metadata is incomplete; use source/category context to identify them.

Open **… → 编辑文档名称**, change the title, then **保存**; **取消** or Escape abandons the edit. The title-map change does not rename the underlying source file. **… → 删除** soft-deletes the source and associated Markdown to the local trash and excludes it from visible results.

**Demonstrated:** the synthetic workbook was renamed `Manual demo — verified rename`, soft-deleted, restored using the actual backend recovery endpoint, and reopened. No pre-existing document was deleted. Recovery uses `POST /api/pdfs/restore` with `{"file":"<relative source path>"}`. A recovery drawer exists in the component, but the current template has no visible button opening it; use the API until that entry is wired. Trash records store a 30-day `purge_after_ts`; that field is not proof that a scheduled purge job runs.

'''+figures(('06-dataset','Document library'),('28-dataset-search','Search for the synthetic workbook'),('29-rename','Rename editing'),('30-delete-demo','After deleting only the demo file'),('42-restored','Demo file restored'),('43-excel-preview','Workbook source preview'),('31-images','Image library'),('32-image-preview','Original image preview'),('46-category-filter','Category filter'),('47-pagination','Pagination'),('48-collapse','Collapsed sidebar')),
'''## 6. 数据集管理、预览与恢复

打开**数据集管理**，按**资料分类 → 设备对象 → 业务场景**筛选，并可附加**使用场景**条件。搜索框用于文档名称或设备类型检索；可切换**文档/图片**、收起侧栏、使用**上一页/下一页**，或勾选行。当前模板中，勾选本身未提供批量处理操作。

点击文档名称打开预览，切换源文件、**抽取结果**和**切分块**，也可打开源文件、全屏及关闭。PDF 使用内嵌页面，图片显示原图，Excel 提供工作表标签和单元格表格。部分已有条目因标题元数据不完整而显示**未知**，需结合源文件和分类辨认。

点击**… → 编辑文档名称**，修改标题并**保存**；**取消**或 Escape 放弃修改。重命名更新标题映射，不改变底层文件名。**… → 删除**将源文件和相关 Markdown 移入本地回收区，并从可见结果排除。

**已演示：** 将合成工作簿改名为 `Manual demo — verified rename`，软删除，再调用实际后端恢复接口，最后重新打开。未删除任何原有文档。恢复接口为 `POST /api/pdfs/restore`，请求体 `{"file":"<源文件相对路径>"}`。组件包含恢复抽屉，但当前模板没有可见打开按钮，需通过接口恢复。回收记录写入 30 天后的 `purge_after_ts`，该字段本身不能证明已有定时清理任务执行。

'''+figures(('06-dataset','文档数据集'),('28-dataset-search','检索合成工作簿'),('29-rename','编辑文档名称'),('30-delete-demo','仅删除演示文件后的状态'),('42-restored','恢复后的演示文件'),('43-excel-preview','源工作簿预览'),('31-images','图片数据集'),('32-image-preview','源图片预览'),('46-category-filter','分类筛选'),('47-pagination','分页'),('48-collapse','收起侧边栏')))
add('''## 7. Vector retrieval and index maintenance

There is no separate vector workbench in the active router. Inspect chunks in the dataset preview, or use the backend endpoints:

- `GET /api/vector/overview`: index summary, distributions and sample chunks.
- `GET /api/vector/docs`: document-level indexing information.
- `GET /api/vector/doc-chunks?doc_id=<id>&limit=200`: ordered chunks and provenance.
- `POST /api/vector/search`: `query`, optional `top_k` (1–100), `category`, `doc_id`. Returns scores, text and available source-page/clause/line metadata.

The search implementation reads a FAISS inner-product index, embeds the query, retrieves candidates, filters by document/category and excludes deleted documents. A dimension mismatch returns HTTP 409 and triggers a rebuild task. An absent index or unavailable embedding model must be resolved before successful semantic retrieval.

**Recorded issue:** overview/docs returned HTTP 200, but fresh retrieval failed because the saved 1,024-dimensional index uses `voyage-4-large` while the default local path tried to load that API model from the local Hugging Face cache. For this Voyage 4 index, set `EMBEDDING_QUERY_MODEL=voyageai/voyage-4-nano`; the local Nano model generates compatible 1,024-dimensional query embeddings without rebuilding the index. Download it once with `LOCAL_EMBEDDING_LOCAL_ONLY=0`, then use `1` for offline operation. A working answer model is also required.

Maintenance endpoints are backend operations: `POST /api/kb/build` (combined), `/api/vector/rebuild` (vector only), `/api/graph/rebuild` (graph only). Poll `GET /api/kb/build/<task_id>` for stages, logs and result. A returned task ID means accepted, not completed. Existing indexes were not deliberately rebuilt for this manual.''','''## 7. 向量检索与索引维护

当前路由没有独立向量工作台。可在数据集预览中查看切分块，或使用后端接口：

- `GET /api/vector/overview`：索引摘要、分布与示例文本块。
- `GET /api/vector/docs`：按文档汇总索引信息。
- `GET /api/vector/doc-chunks?doc_id=<id>&limit=200`：有序文本块与来源信息。
- `POST /api/vector/search`：提供 `query`，可选 `top_k`（1–100）、`category`、`doc_id`；返回分数、文本及可用页码、条款和行号。

检索读取 FAISS 内积索引，对问题向量化，召回候选，再按文档、分类过滤并排除已删除资料。维度不匹配时返回 HTTP 409 并触发重建任务。索引缺失或嵌入模型不可用时，需先解决相应问题。

**录制时的问题：** overview/docs 返回 HTTP 200，但已有 1,024 维索引由 `voyage-4-large` 构建，默认本地路径却尝试从 Hugging Face 缓存加载这一 API 模型，导致新问答检索失败。针对该 Voyage 4 索引，可设置 `EMBEDDING_QUERY_MODEL=voyageai/voyage-4-nano`，本地 Nano 产生兼容的 1,024 维查询向量，无需重建索引。首次下载设置 `LOCAL_EMBEDDING_LOCAL_ONLY=0`，离线运行再改为 `1`；生成回答还需可用的语言模型。

维护接口包括 `POST /api/kb/build`（综合构建）、`/api/vector/rebuild`（仅向量）、`/api/graph/rebuild`（仅图谱）。使用 `GET /api/kb/build/<task_id>` 查询阶段、日志和结果。返回任务 ID 只表示已接受，不表示完成。本次未主动重建已有索引。''')
add('''## 8. Knowledge graph

Open **知识图谱**. Enter equipment, a metric, a fault or standard in **统一检索**, then click **搜索** or press Enter. The page requests a subgraph and evidence chains. Suggestions and topic chips focus matching entities. Select a node to inspect/focus it; drag/zoom the D3 network and use **+**, **−**, **适配**. **刷新图谱** reloads; **图谱大屏展示/回到总览** reset filters.

The visible workspace includes node/edge counts, typed-node counts, current zoom, search results and evidence-chain summaries. Backend entity lookup supports name/type and query limits; chain lookup supports seed limit, chain limit and one/two hops. Typed extraction includes `StandardClause`, `FaultMode`, `InspectionTask`, `MaintenanceAction`, `ThresholdRule`, with relationships linking evidence, faults, inspections and actions.

**Recorded issue and resolution:** The capture showed HTTP 503 because nothing accepted Bolt connections on port 7687. On this machine, starting the existing `neo4j-start-local-neo4j-1` container and setting this project’s `.env` to its working `NEO4J_URI`, `NEO4J_USER`, and `NEO4J_PASSWORD` restored the connection; `/api/graph/overview` now returns HTTP 200. Restart Flask after changing `.env`. On another machine, start a Neo4j instance with Bolt on 7687 and use its actual credentials. To populate or recreate graph content, back up the existing Neo4j database first; `POST /api/graph/rebuild` performs a clean rebuild from saved vector chunks. Check `GET /api/kb/build/<task_id>` before retrying graph search. The screenshots retain the original capture state.

'''+figures(('11-graph','Graph workspace with actual Neo4j state'),('12-graph-search','Keyword search and evidence-chain area')),
'''## 8. 知识图谱

打开**知识图谱**，在**统一检索**输入设备、指标、故障或标准，点击**搜索**或回车。页面请求局部图谱与证据链；建议项和主题标签用于定位实体。选中节点后可检查或聚焦，支持拖动、缩放及 **+**、**−**、**适配**。**刷新图谱**重新加载；**图谱大屏展示/回到总览**重置筛选。

工作区显示节点数、关系数、类型化节点数、缩放比例、搜索结果及证据链摘要。后端实体接口支持名称、类型和数量限制；证据链接口支持种子数量、链路数量以及一跳或两跳。类型化抽取包括 `StandardClause`、`FaultMode`、`InspectionTask`、`MaintenanceAction`、`ThresholdRule`，并建立证据、故障、检查与措施之间的关系。

**录制时的问题与解决方式：** 当时 7687 端口没有可用的 Bolt 服务，`/api/graph/overview` 返回 HTTP 503。本机启动已有容器 `neo4j-start-local-neo4j-1`，并在本项目 `.env` 中设置实际可用的 `NEO4J_URI`、`NEO4J_USER`、`NEO4J_PASSWORD` 后，连接已恢复；该接口现返回 HTTP 200。修改 `.env` 后需重启 Flask。其他机器需启动开放 7687 端口的 Neo4j 并填写实际凭据。如需填充或重建图谱，先备份已有 Neo4j 数据库；`POST /api/graph/rebuild` 会使用已有向量文本块进行清理后重建。通过 `GET /api/kb/build/<task_id>` 查看任务结果，再重新搜索。截图保留录制时状态。

'''+figures(('11-graph','图谱工作区与真实 Neo4j 状态'),('12-graph-search','关键词检索与证据链区域')))
add('''## 9. Evidence-based questions

Open **知识问答**. Choose a suggested category/question or type a question. **Enter** sends; **Ctrl+Enter** inserts a line break. The send button is disabled during execution. **新建对话** starts a fresh conversation; selecting history reopens a saved answer. The history context menu supports deletion of a saved question.

Answers can include inline **【1】** citations, source-document links and a right-hand **引用文本块** panel with up to five evidence excerpts. **查看文档** opens the associated dataset source; **复制** copies the excerpt. Inspect page, clause, section and line metadata where present. These fields describe available source provenance, not a guarantee that each old record has a resolvable PDF.

**Recorded issue and fix:** The fresh DGA question failed before answer generation because the configured local embedding path could not load `voyage-4-large`. The branch adds a local `voyage-4-nano` query option compatible with the saved Voyage 4 index: set `EMBEDDING_QUERY_MODEL=voyageai/voyage-4-nano`, download the model once, and configure a working answer model (for example local Ollama `qwen2.5:7b`). A separate check on this branch returned HTTP 200 for a fresh question with eight evidence chunks using Nano and local Ollama. The capture also reopened a previously saved overheating answer; it was not regenerated.

'''+figures(('13-qa','Question workspace and history'),('14-qa-answer','Actual fresh-question error'),('34-qa-history','Previously saved answer with inline citations'),('35-qa-citations','Historical evidence excerpts')),
'''## 9. 带证据的知识问答

打开**知识问答**，选择推荐类别、示例问题或自行输入。**Enter**发送，**Ctrl+Enter**换行，执行期间发送按钮禁用。**新建对话**开启新会话；点击历史条目重新打开已有回答，历史项上下文菜单支持删除记录。

回答可包含行内 **【1】**、来源文档链接，右侧**引用文本块**最多展示五条证据摘录。**查看文档**打开相关数据集资料，**复制**复制文本块。可查看已有的页码、条款、章节与行号；这些是可用来源信息，并不保证每条旧记录都有可解析的 PDF 链接。

**录制时的问题与处理：** 新提交的油色谱问题在生成回答前失败，因为本地嵌入路径无法加载 `voyage-4-large`。本次分支加入与已有 Voyage 4 索引兼容的本地 `voyage-4-nano` 查询选项：设置 `EMBEDDING_QUERY_MODEL=voyageai/voyage-4-nano`，首次下载模型，并配置可用的回答模型（如本地 Ollama `qwen2.5:7b`）。本分支另行验证了 Nano 与本地 Ollama：新问题返回 HTTP 200，并包含八条证据文本块。录制中打开的过热问题回答为已有历史记录，没有重新生成。

'''+figures(('13-qa','问答工作区与历史记录'),('14-qa-answer','新问题实际返回的错误'),('34-qa-history','已有回答及行内引用'),('35-qa-citations','历史回答的证据摘录')))
add('''## 10. Diagnosis: three input modes

Open **诊断报告** (`/diagnosis`). The tabs select **结构化异常**, **自然语言**, or **混合输入**. Natural language supplies a question; structured mode supplies equipment, symptoms/signals and measured values; hybrid combines both. Switching modes changes the form used for submission.

Structured fields include equipment ID/name/type, station, component, model and voltage; observed phenomena and one-item-per-line symptoms/signals; measurement ID/name/key, value, unit, timestamp and source. Add measurements with **+ 添加测量**, or **移除** an extra row. Enter attention/warning/alarm thresholds and select **数值越高越危险** or **数值越低越危险**. History accepts one `timestamp,value` pair per line. Advanced configuration exposes case ID, retrieval `top_k` and debug output.

**Reproduce the completed demo:** click **加载示例**, inspect its two measurements, then **运行诊断**. The built-in example uses hybrid input. It supplies top-oil temperature 95°C (thresholds 85/90/95) and load rate 87% (80/85/95). The actual output classified them as **alarm** and **warning**, respectively, and overall risk as **Critical**. A persistent report was generated.

Read the result's anomaly summary, fault candidates, checks, maintenance actions, applicability, contradictions, missing evidence and rule hits. Upper/lower threshold direction changes the comparison; a missing threshold is not an automatic normal finding. Evidence-enriched thresholds and discrepancies are displayed when available.

**Interpretation of this run:** vector evidence count and graph candidate count were both zero. The displayed overheating candidate and checks were deterministic fallbacks/standard-topic hints, explicitly labeled in the result. The 85/90/95 values were example inputs, not newly retrieved standard limits. No real equipment was diagnosed.

'''+figures(('36-natural-language','Natural-language input'),('37-structured','Structured anomaly form'),('16-diagnosis-example','Loaded hybrid example'),('17-diagnosis-result','Actual completed diagnosis and report link')),
'''## 10. 三种输入模式的诊断

打开**诊断报告**（`/diagnosis`），在**结构化异常**、**自然语言**和**混合输入**间切换。自然语言模式提交问题；结构化模式提交设备、症状、异常信号及测量；混合模式同时提交两者。切换模式会改变提交表单。

结构化字段包括设备 ID、名称、类型、站点、部件、型号、电压等级，异常现象和每行一项的症状/信号，以及测点 ID、名称、指标键、数值、单位、时间和来源。通过**+ 添加测量**增加条目，通过**移除**删除多余测量。可输入注意、预警、告警值，并选择**数值越高越危险**或**数值越低越危险**。历史序列每行填写 `timestamp,value`。高级配置提供案例 ID、检索 `top_k` 和调试输出。

**复现已完成演示：** 点击**加载示例**，检查两项测量，然后**运行诊断**。内置示例使用混合输入：顶层油温 95°C（阈值 85/90/95），负载率 87%（阈值 80/85/95）。实际结果分别为 **alarm**、**warning**，综合风险为 **Critical**，并生成持久化报告。

结果包含异常摘要、故障候选、检查建议、处置措施、适用性、矛盾、缺失证据及规则命中。上限/下限方向决定比较方式；缺失阈值不等于正常。有证据补全阈值或阈值差异时会显示相应内容。

**本次结果含义：** 向量证据数与图谱候选数均为零。过热候选和检查建议来自确定性回退或标准主题提示，结果中明确标注。85/90/95 是示例输入，不是本次检索得到的标准限值。本次未对真实设备做诊断。

'''+figures(('36-natural-language','自然语言输入'),('37-structured','结构化异常表单'),('16-diagnosis-example','已加载的混合输入示例'),('17-diagnosis-result','实际完成的诊断与报告链接')))
add('''## 11. Saved reports and source evidence

Click **查看完整报告** after a successful run. The saved-report route requires a real report ID; this session generated `rpt-1793633495-f5c289a2`. The report presents input facts and normalized measurements, thresholds/rules, candidates, inspections/actions, and supporting evidence/technical details. Expand **四、附加追踪与技术细节** to inspect pipeline and enrichment notes. Scroll through the full report; the screenshots show its beginning and lower sections.

Reports are persisted as local JSON under `uploads/reports/`. List them with `GET /api/reports`, load one with `GET /api/reports/<report_id>`, or rebuild a report from an available run using `POST /api/reports/from-run/<run_id>`. Run detail is held in process memory, while saved report files survive restart. Keep the report ID to reopen the document.

Evidence buttons open a resolved PDF reference or the dataset document. `/api/references/pdf/<token>` resolves a registered source reference; it requires a real token. In this run, the two supporting evidence items were input observations (SCADA/EMS), not retrieved document excerpts. No successful source-PDF reference from this diagnosis was claimed.

The application has no dedicated report PDF-export button in this view. The Chinese/English PDFs accompanying this manual are generated documentation. Use browser printing separately if a diagnosis report must be printed.

'''+figures(('18-report','Saved report header and measured facts'),('19-report-evidence','Rule-based reasoning and recommendations'),('38-report-bottom','Input-observation evidence panel'),('49-report-reasoning','Fault candidates and action recommendations'),('50-report-pipeline','Expanded technical details and pipeline stages')),
'''## 11. 持久化报告与来源证据

运行成功后点击**查看完整报告**。报告路由必须使用真实 ID；本次生成 `rpt-1793633495-f5c289a2`。页面展示输入事实、归一化测量、阈值和规则、故障候选、检查与措施，以及支持证据和技术细节。展开**四、附加追踪与技术细节**可查看流水线和证据补全记录。需向下滚动阅读完整报告，截图展示开头及下方内容。

报告以 JSON 持久化在 `uploads/reports/`。使用 `GET /api/reports` 列表查询，`GET /api/reports/<report_id>` 读取，或在运行记录仍可用时使用 `POST /api/reports/from-run/<run_id>` 重建报告。运行记录保存在进程内存中，报告文件可跨重启保留；请保存报告 ID。

证据按钮打开已解析的 PDF 引用或数据集文档。`/api/references/pdf/<token>` 解析已注册来源，需要真实 token。本次两项支持证据是 SCADA/EMS 输入观测，不是检索文档片段，未宣称该次诊断成功生成可访问的来源 PDF 引用。

当前报告页面没有专门的 PDF 导出按钮。本手册附带的中英文 PDF 是文档构建产物；需要打印诊断报告时可另用浏览器打印。

'''+figures(('18-report','报告标题与测量事实'),('19-report-evidence','规则推演与建议'),('38-report-bottom','输入观测证据面板'),('49-report-reasoning','故障候选与处置建议'),('50-report-pipeline','展开的技术细节与流水线阶段')))
add('''## 12. Condition monitoring

Open **状态监测**. Its separate file picker imports equipment series directly into InfluxDB. Choose an Excel workbook and click **上传并导入时序数据**. Recognized sheet-name markers are **主变压器时序**, **GIS时序**, **断路器时序**, **主变压器运行日志**. Each usable sheet needs `timestamp` or `log_date`, plus `device_id`. For example, [manual-demo.xlsx](samples/manual-demo.xlsx) supplies `top_oil_temp_c` and `load_mw`.

For **单台设备多指标**, select data type and device, toggle metric chips and choose **归一化对比/原值对比**. Normalization supports shape comparison; read the result table for original values/units. For **单指标多设备**, choose a metric and toggle device chips. **刷新** reruns the current selection; the lower query table shows returned data.

**Recorded issue and required setup:** This page needs InfluxDB OSS v2, but no service was listening on `127.0.0.1:8086`, so the capture showed connection refusal. Start InfluxDB v2, create an organization and bucket, and set `INFLUXDB_URL`, `INFLUXDB_ORG`, `INFLUXDB_BUCKET`, and `INFLUXDB_TOKEN` in `.env`; restart Flask and verify `/api/timeseries/ping` before importing the sample workbook. No time-series write or populated chart was captured. The importer calls `pandas.read_excel`, so use Excel despite the CSV picker; legacy `.xls` also needs its reader engine.

The importer deletes the measurement's existing points across the incoming sheet's date interval (through the following day) before writing new rows. This can replace records for other devices in that interval. The demonstration workbook was uploaded to the knowledge library, not written into a production time-series bucket.

'''+figures(('20-timeseries','Condition monitoring with actual service error'),('21-timeseries-compare','Single-metric multi-device mode')),
'''## 12. 设备状态监测

打开**状态监测**。这里的独立文件选择器将设备时序直接写入 InfluxDB。选择 Excel 工作簿并点击**上传并导入时序数据**。可识别的工作表名称标记为**主变压器时序**、**GIS时序**、**断路器时序**、**主变压器运行日志**。有效表需包含 `timestamp` 或 `log_date`，以及 `device_id`；[manual-demo.xlsx](samples/manual-demo.xlsx) 另含 `top_oil_temp_c`、`load_mw`。

在**单台设备多指标**模式中选择数据类型和设备，通过指标标签控制曲线，选择**归一化对比/原值对比**。归一化适合比较变化形态，原值和单位应结合结果表读取。**单指标多设备**模式选择指标并切换设备标签。**刷新**重新执行当前查询，下方表格显示返回数据。

**录制时的问题与所需配置：** 本页依赖 InfluxDB OSS v2；当时 `127.0.0.1:8086` 没有服务监听，因此显示连接拒绝。启动 InfluxDB v2，创建组织与 bucket，在 `.env` 中设置 `INFLUXDB_URL`、`INFLUXDB_ORG`、`INFLUXDB_BUCKET`、`INFLUXDB_TOKEN`，重启 Flask，并在导入示例工作簿前检查 `/api/timeseries/ping`。录制中没有成功写入时序或展示有数据的曲线。导入器实际调用 `pandas.read_excel`，因此应使用 Excel 文件；旧版 `.xls` 还需读取引擎。

导入器会先删除同一 measurement 中、输入工作表日期区间至下一天的已有点，再写入新行，可能覆盖该区间其他设备的记录。本次工作簿仅导入知识库，未写入生产时序 bucket。

'''+figures(('20-timeseries','状态监测与实际服务错误'),('21-timeseries-compare','单指标多设备模式')))
add('''## 13. Accounts and management

The top **登录 / 注册** button has no bound click handler in `App.vue`. **设置 → 用户管理** navigates to `/manage`. That page displays permissions, monitoring, configuration and audit cards; **进入管理台** has no bound action. **退出** returns home without calling the authentication logout endpoint. These visible controls are not a completed account-management workflow.

The backend does implement combined email-code registration/login: **send code → verify code → store issued session tokens → refresh → logout**. Its routes are `/api/auth/send-code`, `/verify-code`, `/refresh`, `/logout`. Verification creates the user when necessary. SMTP, authentication settings and the local SQLite store support this service. See [auth_api_quickstart.md](../auth_api_quickstart.md) for request/response fields. No email was sent and no real account was created for this manual.

'''+figures(('22-management','Current management entry page')),
'''## 13. 账号与平台管理

`App.vue` 顶部**登录 / 注册**按钮没有绑定点击处理。**设置 → 用户管理**跳转 `/manage`；该页显示权限角色、运行监控、系统配置及审计日志卡片，**进入管理台**也未绑定操作。**退出**只返回首页，不调用后端登出接口。这些可见控件不构成已完成的账号管理流程。

后端已实现邮箱验证码合并注册/登录：**发送验证码 → 验证 → 保存会话令牌 → 刷新 → 登出**，接口为 `/api/auth/send-code`、`/verify-code`、`/refresh`、`/logout`。首次验证可创建用户，服务依赖 SMTP、认证配置及本地 SQLite 存储。请求与返回字段见 [auth_api_quickstart.md](../auth_api_quickstart.md)。本次未发送邮件，也未创建真实账号。

'''+figures(('22-management','当前的平台管理入口')))
add('''## 14. Recordings and screen grabs

The following are actual, silent browser recordings. They move the cursor smoothly along a timed path before each interaction, mark clicks with a pulse, and play at normal speed. Actual waiting and failure states remain visible. MP4 links are broadly compatible; Markdown video embedding depends on the viewer. PDFs show still images and retain video links, not playable embedded video. Keep the `videos/` folder beside the guides.

| Recording | Content |
|---|---|
| [Interface tour — MP4](videos/interface-tour.mp4) | Home/theme/settings; import; dataset PDF/extraction/chunks; graph search; failed fresh Q&A; completed diagnosis/report; monitoring and management |
| [Import and library — MP4](videos/import-and-library.mp4) | Real spreadsheet upload, extraction, draft editing, commit and image preview |
| [Saved evidence — MP4](videos/evidence-and-media.mp4) | Historical answer/citations, diagnosis modes, report evidence, workbook source and edited extraction |
| [Report details — MP4](videos/report-details.mp4) | Scroll through reasoning/actions and expand technical pipeline stages |
| [Library actions — MP4](videos/library-actions.mp4) | Search, rename, soft delete, API-assisted restore, source preview, category filtering, pagination and sidebar collapse |

![Animated import screen recording](videos/import-preview.gif)

![Frame grabbed from the actual diagnosis recording](screenshots/video-grab-diagnosis.png)

![Frame grabbed from the actual import recording](screenshots/video-grab-import.png)

Original WebM recordings are also retained for reproducibility. The recordings demonstrate screen workflows; they are distinct from the system's video-file parsing feature.''','''## 14. 录屏与视频截帧

以下均为实际浏览器无声录屏，鼠标在每次操作前沿连续路径平滑移动，点击处显示光圈，按正常速度播放，同时保留真实等待和失败状态。MP4 链接兼容性较好，Markdown 是否内嵌播放取决于阅读器。PDF 保留静态画面及视频链接，不内嵌可播放视频；使用时请保留同目录 `videos/` 文件夹。

| 录屏 | 内容 |
|---|---|
| [界面全览 — MP4](videos/interface-tour.mp4) | 首页、主题、设置、导入、PDF/抽取/切分块、图谱搜索、新问答失败、完成诊断与报告、监测及管理 |
| [导入与资料库 — MP4](videos/import-and-library.mp4) | 实际 Excel 上传、抽取、草稿编辑、提交及图片预览 |
| [已有证据 — MP4](videos/evidence-and-media.mp4) | 历史回答与引用、诊断模式、报告证据、工作簿原表及编辑稿 |
| [报告详情 — MP4](videos/report-details.mp4) | 滚动查看推演与处置，展开技术追踪及流水线阶段 |
| [数据集操作 — MP4](videos/library-actions.mp4) | 检索、改名、软删除、接口辅助恢复、预览、分类筛选、分页与收起侧栏 |

![导入操作动态录屏](videos/import-preview.gif)

![从实际诊断录屏截取的画面](screenshots/video-grab-diagnosis.png)

![从实际导入录屏截取的画面](screenshots/video-grab-import.png)

另保留原始 WebM，便于复核。这里的视频是屏幕操作录制，与系统的视频文件解析功能不同。''')
add('''## 15. API examples and endpoint catalogue

Use the backend port for direct API calls. JSON operations return structured success/error fields; inspect both HTTP status and `ok`. Uploads use multipart form data. Replace IDs/paths with actual returned values.

```bash
curl http://127.0.0.1:5002/api/vector/overview
curl http://127.0.0.1:5002/api/reports
curl -X POST http://127.0.0.1:5002/api/vector/search \\
  -H 'Content-Type: application/json' \\
  -d '{"query":"变压器油温过高","top_k":5}'
```

The submitted hybrid request is retained as [diagnosis-request.json](samples/diagnosis-request.json); the actual output is [diagnosis-run.json](evidence/diagnosis-run.json).

```bash
curl -X POST http://127.0.0.1:5002/api/diagnosis/run \\
  -H 'Content-Type: application/json' \\
  --data-binary @docs/manual/samples/diagnosis-request.json
```

That POST creates a new local report. The schema/example/validate endpoints concern the diagnostic schema contract; `/api/diagnosis/run` accepts the runtime envelope with `input_type`, `question`, `structured_input`, `top_k`, `case_id`, `include_debug`. Do not submit the schema example directly as a runtime request without checking its structure.

The following catalogue is generated from all Flask route decorators in `app.py` and the registered vector/time-series/auth modules. **Listed** means implemented in source, not that every mutation or service-dependent route succeeded. The source location identifies its actual handler. The broad API fallback is also included.''','''## 15. 接口示例与完整目录

直接请求接口时使用后端端口。JSON 接口返回成功或错误字段，需同时检查 HTTP 状态与 `ok`；上传使用 multipart 表单。将示例 ID 和路径替换为实际返回值。

```bash
curl http://127.0.0.1:5002/api/vector/overview
curl http://127.0.0.1:5002/api/reports
curl -X POST http://127.0.0.1:5002/api/vector/search \\
  -H 'Content-Type: application/json' \\
  -d '{"query":"变压器油温过高","top_k":5}'
```

本次提交的混合输入保存在 [diagnosis-request.json](samples/diagnosis-request.json)，实际返回保存在 [diagnosis-run.json](evidence/diagnosis-run.json)。

```bash
curl -X POST http://127.0.0.1:5002/api/diagnosis/run \\
  -H 'Content-Type: application/json' \\
  --data-binary @docs/manual/samples/diagnosis-request.json
```

该 POST 会生成新的本地报告。schema/example/validate 接口针对诊断 schema 契约；`/api/diagnosis/run` 使用运行时封装，含 `input_type`、`question`、`structured_input`、`top_k`、`case_id`、`include_debug`。需检查结构，不能将 schema 示例不经转换直接当作运行请求。

以下目录从 `app.py` 及已注册的向量、时序和认证模块中全部 Flask 路由装饰器生成。**列出**表示源码已有实现，不表示每项写操作或依赖外部服务的接口均成功执行。源码位置指向实际处理函数，通用 API 兜底路由也包含在内。''')
routes=json.loads((OUT/'evidence/route-inventory.json').read_text())
for lang in (0,1):
 table=['| '+('Method | Route | Handler / source' if lang==0 else '方法 | 路由 | 处理函数 / 源码')+' |','|---|---|---|']
 for r in routes:
  table.append(f"| {'/'.join(r['methods'])} | `{r['route']}` | `{r['function']}` · `{r['source']}:{r['line']}` |")
 if lang==0:en='\n'.join(table)
 else:zh='\n'.join(table)
add(en,zh)
add('''### Backend-only operation recipes

| Operation | Inputs and result |
|---|---|
| Reindex library metadata | `POST /api/pdfs/reindex`; refreshes local file enumeration/title/category metadata, not the FAISS index. |
| Upload and poll | `POST /api/upload-document` with `file`, `file_type`, `document_name`, `parse_strategy`, `target_category`; poll `/api/upload-document/<task_id>`. |
| Reparse | `POST .../<task_id>/reparse` with `parse_strategy`; task must exist and be eligible. |
| Upload source/preview | `GET .../<task_id>/source` or `/spreadsheet-preview`; dataset workbook preview uses `/api/pdfs/spreadsheet-preview?file=...`. |
| Extraction versions | `GET /api/upload-markdown/<task_id>?kind=raw` or `cleaned` or `edited`; edit through `POST .../<task_id>/edit`. |
| Commit | `POST /api/upload-document/<task_id>/commit` with category, `use_edited`, `upload_meta`; returns `dataset_file`. |
| Metadata | `GET /api/fields`; `POST /api/upload-document/<task_id>/metadata` updates upload metadata. |
| History | `GET /api/upload-history`; `DELETE /api/upload-history/<task_id>` removes its history record, not a substitute for dataset deletion. |
| Dataset previews | `/api/pdfs/markdown?file=...&kind=cleaned`; `/api/pdfs/chunks?file=...`. |
| Rename/delete/restore | POST to `/api/pdfs/rename` (`file`, `title`), `/delete` (`file`), `/restore` (`file`); inspect `/deleted`. |
| Statistics | `/api/datasets/summary`, `/distribution`, `/quality`, `/recent-activity`. |
| Graph | `/api/graph/overview`; `/subgraph?q=...`; `/entities?q=...&type=...`; `/entity?norm_name=...&type=...`; `/chain?q=...&max_hops=2`. |
| Q&A | `POST /api/qa/ask` with `question`, `history`; `GET /api/qa/history?limit=12`; delete one record by ID. |
| Monitoring | `/api/timeseries/ping`, `/overview`, `/devices`; `/query?measurement=...&device_id=...&days=30&limit=5000`; multipart `/upload` or JSON `/import` with server-local `local_path`. |
| Auth | send-code (`target`, `channel`); verify-code (`target`, `channel`, `code`); refresh/logout with session-token fields described in the auth quickstart. |

All exposed endpoint families are covered above. For internal implementation functions, [function-inventory.csv](evidence/function-inventory.csv) lists Python and Vue/JavaScript declarations by source and line. It is a navigation inventory, not a claim that each helper has been individually executed.''','''### 仅后端开放的操作配方

| 操作 | 输入与结果 |
|---|---|
| 文件元数据重建 | `POST /api/pdfs/reindex`，刷新文件枚举、标题和分类元数据，不重建 FAISS。 |
| 上传与轮询 | `POST /api/upload-document`，提交 `file`、`file_type`、`document_name`、`parse_strategy`、`target_category`；轮询 `/api/upload-document/<task_id>`。 |
| 重新解析 | `POST .../<task_id>/reparse`，传 `parse_strategy`；任务必须存在并满足条件。 |
| 上传源文件/预览 | `GET .../<task_id>/source` 或 `/spreadsheet-preview`；数据集工作簿用 `/api/pdfs/spreadsheet-preview?file=...`。 |
| 抽取稿版本 | `GET /api/upload-markdown/<task_id>?kind=raw`、`cleaned` 或 `edited`；`POST .../<task_id>/edit` 编辑。 |
| 入库 | `POST /api/upload-document/<task_id>/commit`，传栏目、`use_edited`、`upload_meta`，返回 `dataset_file`。 |
| 元数据 | `GET /api/fields`；`POST /api/upload-document/<task_id>/metadata` 更新上传元数据。 |
| 历史记录 | `GET /api/upload-history`；`DELETE /api/upload-history/<task_id>` 删除历史项，不能替代数据集删除。 |
| 数据集预览 | `/api/pdfs/markdown?file=...&kind=cleaned`；`/api/pdfs/chunks?file=...`。 |
| 改名/删除/恢复 | POST `/api/pdfs/rename`（`file`、`title`）、`/delete`（`file`）、`/restore`（`file`），通过 `/deleted` 查看回收区。 |
| 统计 | `/api/datasets/summary`、`/distribution`、`/quality`、`/recent-activity`。 |
| 图谱 | `/api/graph/overview`、`/subgraph?q=...`、`/entities?q=...&type=...`、`/entity?norm_name=...&type=...`、`/chain?q=...&max_hops=2`。 |
| 问答 | `POST /api/qa/ask`，传 `question`、`history`；`GET /api/qa/history?limit=12`；按 ID 删除记录。 |
| 监测 | `/api/timeseries/ping`、`/overview`、`/devices`；`/query?measurement=...&device_id=...&days=30&limit=5000`；multipart `/upload`，或 JSON `/import` 传服务器本地 `local_path`。 |
| 认证 | send-code（`target`、`channel`）；verify-code（`target`、`channel`、`code`）；refresh/logout 的会话令牌字段见认证接入说明。 |

上表覆盖全部对外接口族。内部实现函数的定位目录见 [function-inventory.csv](evidence/function-inventory.csv)，按源码与行号列出 Python 及 Vue/JavaScript 声明。该清单用于导航，不表示逐一执行过所有辅助函数。''')
add('''## 16. Command-line tools and troubleshooting

Run from the repository root using the project interpreter. `PYTHONPATH=.` lets scripts import `core` reliably.

```bash
venv/bin/python main.py --input-root pdfs --output-root pdfs/markdown --clean
venv/bin/python main.py --clean-only
venv/bin/python main.py --full-page-ocr --overwrite --clean
PYTHONPATH=. venv/bin/python scripts/import_timeseries_excel.py /path/to/data.xlsx
venv/bin/python scripts/import_dga_excel.py /path/to/dga.xlsx --skip-ingest
PYTHONPATH=. venv/bin/python scripts/evaluate_retrieval_strategies.py --help
venv/bin/python scripts/eval_kg_extraction.py
```

| Tool | What it does / required input |
|---|---|
| `main.py` | Bulk PDF conversion and optional cleaning; `--clean-only` cleans existing Markdown; `--overwrite` replaces prior output. |
| `import_timeseries_excel.py` | Uses the same InfluxDB importer and replacement semantics as monitoring. Requires the recognized sheets and live InfluxDB. |
| `import_dga_excel.py` | First-sheet headers must start `H2, CH4, C2H6, C2H4, C2H2, 故障类型`; generates a knowledge summary and can ingest it. `--category`, `--basename`, `--skip-ingest` control output. |
| `evaluate_retrieval_strategies.py` | Compares full-document, sliding-window, paragraph and recursive splitting using embedding or TF-IDF retrieval; supports FAISS/NumPy search and configurable chunk size/overlap/top-k. Consult `--help`. |
| `eval_kg_extraction.py` | Scores typed graph extraction against `docs/kg_extraction_eval_gold.json`; that gold file is absent in this snapshot, so the command needs its dataset before it can run. |
| Worker modules | `core/doc/pipeline_worker.py` and `multimodal_worker.py` are subprocess entry points used by the upload service, rather than independent operator workspaces. |

These maintenance/evaluation commands were documented from source, not rerun to imply fresh experimental results. Files with a ` 2` suffix are duplicate source artifacts, not additional registered product features.

| Symptom | Check / action |
|---|---|
| Frontend opens but API requests fail | Verify backend port and Vite proxy; distinguish the current repository from another running copy. |
| Port 5173 occupied | Vite uses `strictPort`; stop the conflicting server or explicitly choose another port and matching backend. |
| Graph returns 503 | Start Neo4j on Bolt port 7687, set the actual URI/user/password in `.env`, and restart Flask. The existing local container restored HTTP 200; use `/api/graph/rebuild` when graph content must be built. |
| Monitoring fails on 8086 | Start InfluxDB OSS v2; set URL/org/bucket/token in `.env`, restart Flask, verify `/api/timeseries/ping`, then import a recognized Excel sheet. |
| Hugging Face/cache error in Q&A | The saved index uses Voyage 4. Set `EMBEDDING_QUERY_MODEL=voyageai/voyage-4-nano` and download Nano once; configure a working answer model. |
| HTTP 409 from vector search | Query/index dimensions differ; inspect the returned rebuild task and wait for successful completion. |
| Upload processed but not visible in dataset | Finish **保存并入库**; inspect task status and `dataset_file`. Extraction success alone is not commit. |
| Existing item titled 未知 | Inspect source/category and use rename to provide title metadata. |
| Report does not reopen | Use a persisted report ID; a run ID is different and process-local run records can disappear at restart. |
| Markdown video does not play | Open the linked MP4 directly or use the HTML edition. PDF uses stills. |

Evidence files include the route inventory, GET checks, actual diagnosis result, restoration result and visible text captured per screen. Rebuild instructions are in [tools/README.md](tools/README.md).''','''## 16. 命令行工具与故障处理

在仓库根目录使用项目解释器。`PYTHONPATH=.` 可确保脚本找到 `core`。

```bash
venv/bin/python main.py --input-root pdfs --output-root pdfs/markdown --clean
venv/bin/python main.py --clean-only
venv/bin/python main.py --full-page-ocr --overwrite --clean
PYTHONPATH=. venv/bin/python scripts/import_timeseries_excel.py /path/to/data.xlsx
venv/bin/python scripts/import_dga_excel.py /path/to/dga.xlsx --skip-ingest
PYTHONPATH=. venv/bin/python scripts/evaluate_retrieval_strategies.py --help
venv/bin/python scripts/eval_kg_extraction.py
```

| 工具 | 功能与必要输入 |
|---|---|
| `main.py` | 批量 PDF 转换与可选清洗；`--clean-only` 仅清洗已有 Markdown；`--overwrite` 覆盖已有结果。 |
| `import_timeseries_excel.py` | 使用与监测页相同的 InfluxDB 导入器及区间替换语义，需要有效工作表和运行中的 InfluxDB。 |
| `import_dga_excel.py` | 首表表头须以 `H2, CH4, C2H6, C2H4, C2H2, 故障类型` 开始，生成知识摘要并可入库；`--category`、`--basename`、`--skip-ingest` 控制输出。 |
| `evaluate_retrieval_strategies.py` | 比较全文、滑动窗口、段落与递归切分，支持 embedding/TF-IDF 检索、FAISS/NumPy 搜索及块大小、重叠、top-k 参数；详见 `--help`。 |
| `eval_kg_extraction.py` | 依赖 `docs/kg_extraction_eval_gold.json` 对类型化抽取评分；本快照缺少该金标文件，需先提供数据。 |
| Worker 模块 | `core/doc/pipeline_worker.py`、`multimodal_worker.py` 是上传服务调用的子进程入口，不是额外操作页面。 |

这些维护与评估命令依据源码说明，未为本手册重新运行并冒充新实验结果。名称含 ` 2` 后缀的文件是重复源码，不是额外注册的产品功能。

| 现象 | 检查与处理 |
|---|---|
| 前端可打开但接口失败 | 检查后端端口与 Vite 代理，区分本仓库和其他正在运行的副本。 |
| 5173 已占用 | Vite 使用 `strictPort`；停止冲突服务或明确使用其他端口并匹配后端。 |
| 图谱返回 503 | 启动 7687 端口的 Neo4j，在 `.env` 中设置实际 URI/用户名/密码并重启 Flask；本机已有容器恢复接口 HTTP 200，需重建图谱内容时使用 `/api/graph/rebuild`。 |
| 监测连接 8086 失败 | 启动 InfluxDB OSS v2，在 `.env` 中设置 URL/org/bucket/token，重启 Flask、检查 `/api/timeseries/ping` 后导入规定格式的 Excel。 |
| 问答显示 Hugging Face/缓存错误 | 已有索引使用 Voyage 4；设置 `EMBEDDING_QUERY_MODEL=voyageai/voyage-4-nano` 并首次下载 Nano，同时配置可用的回答模型。 |
| 向量检索返回 HTTP 409 | 查询与索引维度不同，检查返回的重建任务并等待成功。 |
| 抽取完成但数据集中找不到 | 完成**保存并入库**，检查任务和 `dataset_file`；抽取成功不等于已提交。 |
| 已有条目标题为“未知” | 查看原文与分类，通过重命名补充标题。 |
| 报告无法重新打开 | 使用持久化 report ID；run ID 不同，且进程内运行记录可能在重启后消失。 |
| Markdown 无法播放视频 | 直接打开 MP4 链接，或使用 HTML 版；PDF 展示静态画面。 |

证据目录包含路由清单、GET 检查、实际诊断结果、恢复结果及逐页可见文本。构建说明见 [tools/README.md](tools/README.md)。''')
for i,name in [(0,'INTERFACE_GUIDE'),(1,'INTERFACE_GUIDE_ZH')]:
 (OUT/f'{name}.md').write_text('\n\n'.join(x[i] for x in sections)+'\n')
run=json.loads((OUT/'evidence/diagnosis-run.json').read_text())
(OUT/'samples/diagnosis-request.json').write_text(json.dumps(run['request'],ensure_ascii=False,indent=2)+'\n')
# Index declarations without importing application code or initializing services.
rows=[]
for file in [ROOT/'app.py',ROOT/'main.py',*sorted((ROOT/'core').rglob('*.py')),*sorted((ROOT/'scripts').glob('*.py'))]:
 try:tree=ast.parse(file.read_text())
 except (SyntaxError,UnicodeDecodeError):continue
 for node in ast.walk(tree):
  if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
   rows.append([str(file.relative_to(ROOT)),node.lineno,node.name,'Python declaration'])
for file in sorted((ROOT/'frontend/src').rglob('*')):
 if file.suffix not in {'.js','.vue'}:continue
 for i,line in enumerate(file.read_text().splitlines(),1):
  m=re.match(r'\s*(?:async\s+)?(?:function\s+)?([A-Za-z_$][\w$]*)\s*\([^;]*\)\s*\{',line)
  if m and m[1] not in {'if','for','while','switch','catch','with'}:rows.append([str(file.relative_to(ROOT)),i,m[1],'JS method/function (lexical)'])
with (OUT/'evidence/function-inventory.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['source','line','symbol','kind']);w.writerows(rows)
print(f'Wrote bilingual guides; {len(routes)} route decorators; {len(rows)} implementation declarations.')
