const {chromium}=require(process.env.PLAYWRIGHT_MODULE || '/tmp/agent-manual-browser/node_modules/playwright');
const fs=require('fs'),path=require('path');
const out=path.resolve('docs/manual');
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/home/josh/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome'});
 const context=await browser.newContext({viewport:{width:1600,height:1000},recordVideo:{dir:out+'/videos/raw',size:{width:1280,height:800}}});
 const page=await context.newPage();await require('./cursor.cjs').instrument(page);const evidence=[];
 page.on('response',async r=>{if(r.url().includes('/api/')){try{evidence.push({url:r.url().replace('http://127.0.0.1:5175',''),status:r.status(),body:(await r.text()).slice(0,1800)})}catch{}}});
 async function shot(id){await page.waitForTimeout(1200);await page.screenshot({path:out+'/screenshots/'+id+'.png',fullPage:false});fs.writeFileSync(out+'/evidence/'+id+'.txt',await page.locator('body').innerText());console.log(id);}
 async function go(route,id){await page.goto('http://127.0.0.1:5175'+route,{waitUntil:'domcontentloaded'});await page.waitForTimeout(1800);await shot(id);}
 await go('/','01-home');await page.getByRole('switch').click();await shot('02-theme');await page.getByRole('switch').click();
 await page.getByRole('button',{name:'设置',exact:true}).click();await shot('03-settings');
 await go('/parse','04-import');await go('/parse/create','05-upload');
 await go('/dataset','06-dataset');
 console.log('rows',await page.locator('.name-link-btn').count());
 if(await page.locator('.name-link-btn').count()){
 await page.locator('.name-link-btn').first().click();await shot('07-source');
 await page.getByRole('button',{name:'抽取结果',exact:true}).click();await shot('08-extraction');
 const btn=page.locator('.dataset-markdown-modal-head button').filter({hasText:/切分/});if(await btn.count()){await btn.first().click();await shot('09-chunks')}
 await page.getByTitle('关闭',{exact:true}).click();
 await page.getByTitle('更多操作').first().click();await shot('10-document-actions');
 }
 await page.goto('http://127.0.0.1:5175/graph',{waitUntil:'domcontentloaded'});await page.waitForTimeout(4500);await page.getByTitle('适配').click();await shot('11-graph');
 await page.locator('.kg3-search-input, input').first().fill('油温');await page.getByRole('button',{name:'搜索',exact:true}).click();await page.waitForTimeout(1800);await page.getByTitle('适配').click();await shot('12-graph-search');
 await go('/qa','13-qa');
 await page.locator('textarea').fill('变压器油中溶解气体分析可用于判断哪些故障类型？');
 const send=page.locator('.qa-send-btn');if(await send.count()){await send.click();await page.waitForTimeout(18000);await shot('14-qa-answer')}
 await go('/diagnosis','15-diagnosis');
 await page.getByRole('button',{name:'加载示例',exact:true}).click();await shot('16-diagnosis-example');
 const responsePromise=page.waitForResponse(r=>r.url().includes('/api/diagnosis/run')&&r.request().method()==='POST',{timeout:120000});
 await page.locator('.diag-btn-primary').first().click();
 try{const r=await responsePromise;const result=await r.json();fs.writeFileSync(out+'/evidence/diagnosis-run.json',JSON.stringify(result,null,2));await shot('17-diagnosis-result');if(result.report?.report_id){await go('/reports/'+result.report.report_id,'18-report');await page.evaluate(()=>window.scrollTo(0,document.body.scrollHeight/2));await shot('19-report-evidence')}}catch(e){console.log(e.message);await shot('17-diagnosis-result')}
 await go('/timeseries','20-timeseries');
 await page.locator('select').first().selectOption('metric_compare');await shot('21-timeseries-compare');
 await go('/manage','22-management');
 fs.writeFileSync(out+'/evidence/browser-api.json',JSON.stringify(evidence,null,2));
 const video=page.video();await context.close();await video.saveAs(out+'/videos/interface-tour.webm');await browser.close();
})();
