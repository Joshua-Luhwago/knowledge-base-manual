const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'/tmp/agent-manual-browser/node_modules/playwright');const fs=require('fs'),path=require('path');const out=path.resolve('docs/manual');
(async()=>{const b=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/home/josh/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome'});const c=await b.newContext({viewport:{width:1600,height:1000},recordVideo:{dir:out+'/videos/raw',size:{width:1280,height:800}}});const p=await c.newPage();await require('./cursor.cjs').instrument(p);p.setDefaultTimeout(15000);
async function shot(id){await p.waitForTimeout(1700);await p.screenshot({path:out+'/screenshots/'+id+'.png'});fs.writeFileSync(out+'/evidence/'+id+'.txt',await p.locator('body').innerText());console.log(id)}
await p.goto('http://127.0.0.1:5175/parse/create');await p.locator('input[type=file]').first().setInputFiles(out+'/samples/manual-demo.xlsx');await shot('23-upload-selected');
await p.getByPlaceholder('请输入文档名称').fill('Manual demo — synthetic transformer readings');
await p.locator('.upload-actions button').click();
await p.waitForTimeout(6000);await shot('24-upload-processed');
if(await p.locator('.parse-stage-close-btn').count())await p.locator('.parse-stage-close-btn').click();
if(await p.getByRole('button',{name:'编辑',exact:true}).first().isEnabled()){await p.getByRole('button',{name:'编辑',exact:true}).first().click();await p.locator('.markdown-editor').first().fill('# Manual demo — synthetic data\n\nThese two rows are demonstration inputs, not field readings.\n\n|Device|Top oil temperature|\n|---|---|\n|MANUAL-DEMO-001|72 C|\n|MANUAL-DEMO-001|76 C|\n');await shot('25-markdown-edit');await p.getByRole('button',{name:'保存',exact:true}).first().click();await shot('26-markdown-saved');}
const save=p.getByRole('button',{name:'保存并入库',exact:true});if(await save.isEnabled()){await save.click();await p.waitForTimeout(2500);await shot('27-committed');}
await p.goto('http://127.0.0.1:5175/dataset');await p.waitForTimeout(4000);await p.getByPlaceholder(/搜索文档名称/).fill('Manual demo');await shot('28-dataset-search');
if(await p.getByTitle('更多操作').count()){await p.getByTitle('更多操作').first().click();await p.getByRole('button',{name:'编辑文档名称',exact:true}).click();await shot('29-rename');await p.getByRole('button',{name:'取消',exact:true}).click();
p.on('dialog',d=>d.accept());await p.getByTitle('更多操作').first().click();await p.getByRole('button',{name:'删除',exact:true}).click();await shot('30-delete-demo');}
await p.goto('http://127.0.0.1:5175/dataset');await p.waitForTimeout(2500);await p.getByRole('button',{name:'图片',exact:true}).click();await shot('31-images');if(await p.locator('.name-link-btn').count()){await p.locator('.name-link-btn').first().click();await shot('32-image-preview')}
await p.goto('http://127.0.0.1:5175/parse');await p.waitForTimeout(2000);const filters=p.locator('select');console.log('filters',await filters.count());if(await filters.count()){console.log(await filters.first().innerText());}
await p.goto('http://127.0.0.1:5175/');await p.waitForTimeout(12000);await shot('33-home-loaded');
const video=p.video();await c.close();await video.saveAs(out+'/videos/import-and-library.webm');await b.close()})();
