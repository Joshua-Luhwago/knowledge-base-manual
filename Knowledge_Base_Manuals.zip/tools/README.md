# Rebuilding the manuals

Run from the repository root. Documentation generation uses the existing project Python environment; no packages were installed in conda base.

1. `venv/bin/python docs/manual/tools/build_manuals.py` writes both Markdown editions and declaration inventories from reviewed bilingual content and saved evidence.
2. `node docs/manual/tools/render.cjs` converts Markdown to HTML, checks every image, and prints both PDFs with Chromium and CJK fonts.

The renderer requires Node packages `playwright` and `marked`, a compatible Chromium executable, and installed Chinese fonts. If Ghostscript is installed, it optimizes the embedded PDF images for smaller distribution files. This machine reused tooling in `/tmp/agent-manual-browser/node_modules`. For another machine, set:

```bash
export PLAYWRIGHT_MODULE=/absolute/path/to/node_modules/playwright
export MARKED_MODULE=/absolute/path/to/node_modules/marked/lib/marked.esm.js
export CHROMIUM_PATH=/absolute/path/to/chrome
```

Provision Node packages in a dedicated tooling directory if needed. Playwright video recording also needs its compatible FFmpeg download. System FFmpeg converts recordings to MP4/GIF and extracts stills.

## Capture scripts

`capture.cjs` records the general tour. `workflows.cjs` uploads a synthetic workbook, edits it and commits it. `details.cjs` opens historical answers and report/evidence views. `library-actions.cjs` renames and soft-deletes the demo workbook, restores it through the API and exercises library controls. `report-scroll.cjs` records expanded report details. They are reproducibility aids tied to the November snapshot, not automatic application tests.

Current capture URLs are `http://127.0.0.1:5176` (frontend) and `http://127.0.0.1:5004` (backend). Point the backend at an isolated Neo4j database with `NEO4J_URI`, `NEO4J_USER`, and `NEO4J_PASSWORD`, and an isolated InfluxDB v2 bucket with `INFLUXDB_URL`, `INFLUXDB_ORG`, `INFLUXDB_BUCKET`, and `INFLUXDB_TOKEN`. Back up an existing graph database before using `/api/graph/rebuild`. Start capture servers with:

```bash
DISABLE_KB_BOOTSTRAP=1 BACKEND_PORT=5004 FLASK_HOST=127.0.0.1 venv/bin/python app.py
```

```bash
cd frontend
BACKEND_PORT=5004 npm run dev -- --host 127.0.0.1 --port 5176
```

Run the tour with `DEMO_BASE_URL=http://127.0.0.1:5176 node docs/manual/tools/capture.cjs`. Import `docs/manual/samples/monitoring-demo.xlsx` into the isolated InfluxDB bucket before recording.

Capture scripts **change local demo data**: they create uploads/reports, edit and commit the demo workbook, modify its display title and exercise soft deletion/recovery. Do not run them blindly against another dataset. Only the named synthetic demo was deleted in this session. The title-map file was restored after screenshots; the captured temporary rename remains visible in screenshots and recordings. The uploaded demo and generated report remain in ignored local storage.

Raw video captures are WebM. The capture scripts move the real browser mouse through timed intermediate positions, interpolate the displayed pointer between captured frames, and show a click pulse. MP4 conversion keeps normal playback speed:

```bash
ffmpeg -i input.webm -c:v libx264 -crf 25 -pix_fmt yuv420p -movflags +faststart output.mp4
```

PDFs reference sibling video files; keep the folder structure when sharing. The HTML edition has native video controls. Markdown uses linked recordings and an animated GIF; PDF contains still images.
