const script = () => {
  const mount = () => {
    if (document.getElementById('guide-cursor')) return;
    const style = document.createElement('style');
    style.textContent = `#guide-cursor{position:fixed;left:0;top:0;width:32px;height:32px;z-index:2147483646;pointer-events:none;transform:translate(-3px,-2px);filter:drop-shadow(0 2px 2px #0008);transition:left .06s linear,top .06s linear}#guide-cursor svg{width:32px;height:32px}#guide-cursor-label{position:fixed;z-index:2147483647;pointer-events:none;background:#eaffe9;border:2px solid #077d55;color:#064a32;border-radius:8px;padding:4px 9px;font:700 17px/1.1 Arial,sans-serif;opacity:0;transition:opacity .12s;box-shadow:0 3px 10px #0006}#guide-cursor-label.on{opacity:1}.guide-click-ring{position:fixed;z-index:2147483645;pointer-events:none;width:20px;height:20px;border:4px solid #ffdb43;border-radius:50%;transform:translate(-50%,-50%);animation:guide-pulse 1s ease-out forwards}@keyframes guide-pulse{to{width:76px;height:76px;opacity:0}}`;
    document.documentElement.appendChild(style);
    const cursor=document.createElement('div');cursor.id='guide-cursor';cursor.innerHTML='<svg viewBox="0 0 32 32"><path d="M2 2 L2 25 L9 19 L14 30 L20 27 L15 17 L25 16 Z" fill="#fff" stroke="#103d5b" stroke-width="2.5" stroke-linejoin="round"/></svg>';
    const label=document.createElement('div');label.id='guide-cursor-label';label.textContent='CLICK';
    document.documentElement.append(cursor,label);
    let x=160,y=130,timer;
    try { const saved=JSON.parse(sessionStorage.getItem('guide-cursor-position')||'null'); if(saved){x=saved.x;y=saved.y} } catch {}
    const place=(a,b)=>{x=a;y=b;cursor.style.left=x+'px';cursor.style.top=y+'px';label.style.left=Math.min(x+28,innerWidth-110)+'px';label.style.top=Math.min(y+20,innerHeight-45)+'px';try{sessionStorage.setItem('guide-cursor-position',JSON.stringify({x,y}))}catch{}};
    place(x,y);
    document.addEventListener('mousemove',e=>place(e.clientX,e.clientY),true);
    document.addEventListener('click',e=>{place(e.clientX,e.clientY);const ring=document.createElement('div');ring.className='guide-click-ring';ring.style.left=x+'px';ring.style.top=y+'px';document.documentElement.appendChild(ring);setTimeout(()=>ring.remove(),1100);label.classList.add('on');clearTimeout(timer);timer=setTimeout(()=>label.classList.remove('on'),1050)},true);
  };
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount,{once:true});else mount();
};
async function instrument(page) {
  await page.addInitScript(script);
  await page.evaluate(script);
  const locatorPrototype=Object.getPrototypeOf(page.locator('body'));
  let position={x:160,y:130};
  const smoothMove=async locator=>{
    try{
      await locator.scrollIntoViewIfNeeded({timeout:5000});
      const box=await locator.boundingBox({timeout:5000});
      if(!box)return;
      const target={x:box.x+box.width/2,y:box.y+box.height/2};
      const start={...position};
      const distance=Math.hypot(target.x-start.x,target.y-start.y);
      const steps=Math.max(12,Math.min(28,Math.ceil(distance/35)));
      for(let i=1;i<=steps;i++){
        const t=i/steps;
        const eased=t*t*(3-2*t);
        const x=start.x+(target.x-start.x)*eased;
        const y=start.y+(target.y-start.y)*eased;
        await page.mouse.move(x,y);
        await page.waitForTimeout(4);
      }
      position=target;
      await page.waitForTimeout(60);
    }catch{}
  };
  for(const method of ['click','fill','selectOption']){
    const original=locatorPrototype[method];
    locatorPrototype[method]=async function(...args){
      await smoothMove(this);
      const result=await original.apply(this,args);
      if(method==='click')await page.waitForTimeout(180);
      return result;
    };
  }
  page.on('framenavigated', async frame => {if(frame===page.mainFrame()){try{await page.waitForTimeout(650)}catch{}}});
}
module.exports={instrument};
