# Validation record — 3 November 2026

- Both Markdown editions render to HTML and PDF (43 English pages; 42 Chinese pages). The renderer confirmed every image loaded.
- The refreshed tour used the branch frontend at `5176` and Flask at `5004`, with an isolated Neo4j copy on Bolt port `7688` and an isolated InfluxDB bucket on port `8087`. The original Neo4j database was backed up and left unchanged.
- Graph construction from 5,719 saved vector chunks completed with `KG_EXTRACT_MODE=rule`. The isolated graph contains 13,358 nodes and 35,417 relationships. Graph overview, subgraph search and chain search returned HTTP 200.
- Local Voyage 4 Nano returned a normalized 1,024-dimensional query vector. Vector search returned HTTP 200 with three hits; fresh Q&A using local Ollama returned HTTP 200 with eight evidence chunks and a cited answer.
- A local Nano document encoder appended one synthetic document to a temporary copy of the saved Voyage 4 FAISS index: 5,719 to 5,720 vectors. The new document ranked first for its test query. The original index was not changed.
- The example diagnosis returned `closed_loop_evaluated`, `Critical`, six vector evidence chunks, 18 typed graph candidates and a persisted report with 2 input observations, 20 typed graph support items, 6 standard-clause items and 1 vector evidence item.
- The isolated InfluxDB demo imported 24 synthetic points for two devices. Ping, overview, devices and series queries returned HTTP 200; both chart modes rendered populated series. A repeat-import check updated one device while preserving another device's points. A recognized CSV uploaded successfully; an unrecognized CSV returned HTTP 400.
- Fourteen read-only GET endpoints returned HTTP 200; results are in `api-checks.json`. Targeted monitoring results are in `monitoring-checks.json`.
- Project dependencies were installed only in this branch's virtual environment. The original main worktree and Neo4j database were not edited for this capture.
