# Validation record — 4 November 2026

- Both Markdown editions rendered to HTML and PDF (45 English pages; 44 Chinese pages). The renderer confirmed every image loaded.
- The refreshed tour used the feature worktree frontend at `5176` and Flask at `5004`. Graph browsing and search read the populated Neo4j database on Bolt `7688`; no graph rebuild or graph write was performed. Monitoring read the isolated InfluxDB bucket on `8087`.
- Neo4j contained 380 nodes and 1,314 relationships before capture. Graph overview, subgraph search and chain search returned HTTP 200. Searching `变压器` returned 174 subgraph nodes, 135 edges and ten evidence chains; see `graph-checks.json`.
- The fresh Q&A request returned HTTP 200 with a cited answer, document links and populated evidence panel. The local query encoder used Voyage 4 Nano against the saved Voyage 4 index.
- The built-in hybrid diagnosis returned HTTP 200, `Critical`, six vector evidence chunks and zero typed graph candidates for its oil-temperature topic. Its persisted report contains two measurement facts, 12 standard-clause excerpts and one vector threshold reference.
- The isolated monitoring bucket contained 24 synthetic points for two devices. Overview, devices and chart queries returned HTTP 200; complete charts were captured in both display modes.
- An earlier isolated append test added one synthetic document to a temporary copy of the saved FAISS index (5,719 to 5,720 vectors) without changing the original index. The source workbook upload was not rerun for this capture.
- Project dependencies stayed in this worktree's virtual environment. The original main worktree and the connected Neo4j graph were not edited by the capture.
