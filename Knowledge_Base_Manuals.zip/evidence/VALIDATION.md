# Validation record — 3 November 2026

- Both Markdown editions render to HTML and PDF (43 English pages; 42 Chinese pages). The renderer checks image loading and local links.
- The graph demo used the project branch at `5175` and `5003` with an isolated Neo4j copy on Bolt port `7688`. The original database was backed up and left unchanged.
- Graph construction from 5,719 saved vector chunks completed with `KG_EXTRACT_MODE=rule`. The isolated graph contains 13,358 nodes and 35,417 relationships. Graph overview, subgraph search, and chain search returned HTTP 200; `graph-checks.json` records the results.
- Updated graph and report screenshots and the interface tour show the populated graph and graph-supported diagnosis. The example diagnosis returned `closed_loop_evaluated`, `Critical`, 18 typed graph candidates, and a persisted report with 2 input observations and 21 graph support items.
- Fourteen read-only GET endpoints were probed; results are in `api-checks.json`. Time-series overview returned HTTP 500 because InfluxDB was unavailable.
- No Python package was installed into conda base. Project commands used the project virtual environment. Application source changes are isolated on `feat/local-voyage-nano`; the original database and main worktree were not edited for this capture.
